#!/bin/bash
echo "Launching PLEXCOM GUI..."
electron .
