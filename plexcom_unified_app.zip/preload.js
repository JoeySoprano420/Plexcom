const { contextBridge } = require('electron');
contextBridge.exposeInMainWorld('plexAPI', {
  launchModule: (name) => {
    console.log(`Launching module: ${name}`);
  }
});