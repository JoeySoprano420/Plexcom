#!/bin/bash
echo "Launching PLEXCOM..."
electron .